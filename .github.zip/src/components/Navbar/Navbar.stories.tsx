import { Meta, StoryObj } from '@storybook/react';
import { within, userEvent } from '@storybook/testing-library';
import { expect } from '@storybook/jest';
import Navbar from './Navbar';

const meta: Meta<typeof Navbar> = {
  title: 'Components/Navbar',
  component: Navbar,
  argTypes: {
    links: {
      Control: 'array',
      defaultValue: [
        { href: '#home', label: 'Home' },
        { href: '#about', label: 'About' },
        { href: '#contact', label: 'Contact' },
      ],
    },
    backgroundColor: { control: 'color', defaultValue: '#333' },
    linkColor: { control: 'color', defaultValue: '#fff' },
    hoverColor: { control: 'color', defaultValue: '#aaa' },
    activeLink: { control: 'text', defaultValue: '#home' },
    disabled: { control: 'boolean', defaultValue: false },
  },
};

export default meta;
type Story = StoryObj<typeof Navbar>;

export const Default: Story = {
  args: {
    links: [
      { href: '#home', label: 'Home' },
      { href: '#about', label: 'About' },
      { href: '#contact', label: 'Contact' },
    ],
    backgroundColor: '#333',
    linkColor: '#fff',
    hoverColor: '#aaa',
    activeLink: '#home',
    disabled: false,
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    const homeLink = canvas.getByText('Home');
    const aboutLink = canvas.getByText('About');
    const contactLink = canvas.getByText('Contact');

    await expect(homeLink).toBeVisible();
    await expect(aboutLink).toBeVisible();
    await expect(contactLink).toBeVisible();
    await expect(homeLink).toHaveClass('active');
  },
};

export const Hovered: Story = {
  args: {
    links: [
      { href: '#home', label: 'Home' },
      { href: '#about', label: 'About' },
      { href: '#contact', label: 'Contact' },
    ],
    backgroundColor: '#333',
    linkColor: '#fff',
    hoverColor: '#aaa',
    activeLink: '#home',
    disabled: false,
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    const aboutLink = canvas.getByText('About');
    
    await userEvent.hover(aboutLink);
    await expect(aboutLink).toHaveStyle(`color: rgb(255, 255, 255)`);
  },
};

export const Active: Story = {
  args: {
    links: [
      { href: '#home', label: 'Home' },
      { href: '#about', label: 'About' },
      { href: '#contact', label: 'Contact' },
    ],
    backgroundColor: '#333',
    linkColor: '#fff',
    hoverColor: '#aaa',
    activeLink: '#about',
    disabled: false,
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    const aboutLink = canvas.getByText('About');

    await expect(aboutLink).toHaveClass('active');
  },
};

export const Collapsed: Story = {
  args: {
    links: [
      { href: '#home', label: 'Home' },
      { href: '#about', label: 'About' },
      { href: '#contact', label: 'Contact' },
    ],
    backgroundColor: '#333',
    linkColor: '#fff',
    hoverColor: '#aaa',
    activeLink: '#home',
    disabled: false,
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile1',
    },
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    const homeLink = canvas.getByText('Home');
    const aboutLink = canvas.getByText('About');
    const contactLink = canvas.getByText('Contact');

    await expect(homeLink).toBeVisible();
    await expect(aboutLink).toBeVisible();
    await expect(contactLink).toBeVisible();
  },
};

export const Disabled: Story = {
  args: {
    links: [
      { href: '#home', label: 'Home' },
      { href: '#about', label: 'About' },
      { href: '#contact', label: 'Contact' },
    ],
    backgroundColor: '#333',
    linkColor: '#fff',
    hoverColor: '#aaa',
    activeLink: '#home',
    disabled: true,
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    const homeLink = canvas.getByText('Home');

    await expect(homeLink).toHaveStyle('pointer-events: none');
    await expect(homeLink).toHaveStyle('opacity: 0.5');
  },
};
