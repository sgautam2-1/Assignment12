export interface LogoProps {
    src: string;
    alt: string;
    size?: string;
    onClick?: () => void;
    disabled?: boolean;
  }
  