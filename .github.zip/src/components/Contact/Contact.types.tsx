export interface ContactProps {
    disabled?: boolean;
  }
  