
export { default } from './Card';

