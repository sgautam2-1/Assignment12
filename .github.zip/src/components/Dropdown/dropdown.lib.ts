// Logic to determine if an option is valid
export const isValidOption = (options: string[], option: string): boolean => {
    return options.includes(option);
  };
  