export { default } from './SearchBar';
