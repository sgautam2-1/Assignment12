import React from 'react';
import Navbar from './components/Navbar';
import Section from './components/Section/Index';
import Footer from './components/Footer';
import Card from './components/Card';
import Label from './components/Label';
import Text from './components/Text';
import './App.css';


// Import images from the new directory
import cmsImage from './assets/images/cms.jpg';
import ecommerceImage from './assets/images/ecommerce.png';
import freelancerImage from './assets/images/freelancer.png';
import sauravImage from './assets/images/saurav_image.jpg';
import testinomial1Image from './assets/images/testinomial1.jpg';
import testinomial2Image from './assets/images/testinomial2.jpg';
import testinomial3Image from './assets/images/testinomial3.jpg';

const App: React.FC = () => {
  const testinomials = [
    {
      id: '1',
      text: 'Saurav did an excellent job on our project. Highly recommended!',
      author: 'John Doe',
      imageUrl: testinomial1Image,
    },
    {
      id: '2',
      text: 'Amazing work! Very satisfied with the results.',
      author: 'Jane Smith',
      imageUrl: testinomial2Image,
    },
    {
      id: '3',
      text: 'Professional and timely delivery. Will hire again.',
      author: 'Emily Johnson',
      imageUrl: testinomial3Image,
    },
  ];

  const projects = [
    {
      id: '1',
      title: 'CMS project',
      description: 'A comprehensive content management system that allows users to create, edit, and publish digital content. It supports multiple users and roles, offers version control, and integrates with various third-party tools for enhanced functionality.',
      imageUrl: cmsImage,
    },
    {
      id: '2',
      title: 'E-commerce project',
      description: 'An advanced e-commerce platform featuring a user-friendly interface, secure payment gateway integration, inventory management, and customizable product listings. It supports multiple payment methods and offers detailed analytics for tracking sales and performance.',
      imageUrl: ecommerceImage,
    },
    {
      id: '3',
      title: 'Freelancing projects',
      description: 'Various freelance projects ranging from website development to custom software solutions. Each project is tailored to meet the specific needs of the client, ensuring high-quality deliverables and timely completion.',
      imageUrl: freelancerImage,
    },
  ];

  return (
    <div className="App">
      <header>
        <div>Logo</div>
        <Navbar
          links={[
            { href: '#about', label: 'About' },
            { href: '#projects', label: 'Projects' },
            { href: '#testinomials', label: 'testinomials' },
            { href: '#contact', label: 'Contact' },
          ]}
          activeLink="#about"
        />
      </header>

      <section id="about">
        <Section
          title={<Label> About Myself </Label> }
          content={
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <img src={sauravImage} alt="About Me" style={{ width: '300px', height: '300px', marginRight: '20px' }} />
              <div>
                <Text>I am Saurav Gautam, a full stack web developer with a passion for creating dynamic and responsive web applications. I also take on freelance projects, delivering high-quality work to my clients.</Text>
              </div>
            </div>
          }
          backgroundColor="#ffcccb"
          titleColor="#8b0000"
          textColor="#333"
          direction="row"
        />
      </section>

      <section id="projects">
        <Section
          title={<Label> My project</Label> }
          content={
            <div className="card-container">
              {projects.map(project => (
                <Card
                  key={project.id}
                  title={project.title}
                  description={project.description}
                  imageUrl={project.imageUrl}
                  visible={true}
                  disabled={false}
                
                /> 
              ))}
            </div>
          }
          backgroundColor="#ffebee"
          titleColor="#8b0000"
          textColor="#333"
          direction="row"
        />
      </section>

      <div style={{ height: '40px' }}></div> {/* Padding between sections */}

     
      <section id="testinomials">
        <Section
          title={<Label> Testinomials?</Label>}
          content={
            <div className="card-container">
              {testinomials.map(testinomial => (
                <Card
                  key={testinomial.id}
                  title={testinomial.author}
                  description={testinomial.text}
                  imageUrl={testinomial.imageUrl}
                  visible={true}
                  disabled={false}
                />
              ))}
            </div>
          }
          backgroundColor="#ffcdd2"
          titleColor="#8b0000"
          textColor="#333"
          direction="row" 
        />
      </section>

      <footer>
        <div className="social-links">
          <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">Twitter</a>
          <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer">LinkedIn</a>
        </div>
        <div className="mini-nav">
          <a href="#home">Home</a>
          <a href="#about">About</a>
          <a href="#contact">Contact</a>
        </div>
        <div className="privacy-policy">
          © 2024 Saurav Gautam. All rights reserved.
        </div>
      </footer>
    </div>
  );
};

export default App;
