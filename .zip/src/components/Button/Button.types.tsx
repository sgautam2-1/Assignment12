export interface ButtonProps {
  children: React.ReactNode;
  disabled?: boolean;
  backgroundColor?: string;
}
