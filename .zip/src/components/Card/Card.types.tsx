export interface CustomCardProps {
  children: React.ReactNode;
  disabled?: boolean;
  backgroundColor?: string;
}
