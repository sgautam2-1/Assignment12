export interface LabelProps {
  children: React.ReactNode;
  disabled?: boolean;
  backgroundColor?: string;
}
