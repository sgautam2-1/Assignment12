// Example logic for validation (if needed)
export const isButtonDisabled = (condition: boolean): boolean => {
    return condition;
  };
  