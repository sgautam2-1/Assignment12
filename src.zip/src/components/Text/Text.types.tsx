
export interface TextProps {
  children: React.ReactNode;
  disabled?: boolean;
  backgroundColor?: string;
  visible?: boolean;
}
