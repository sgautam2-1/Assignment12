
export { default } from './Text';

