
export { default } from './Label';

