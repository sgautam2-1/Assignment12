
export const shouldDisplayLabel = (visible: boolean, disabled: boolean): boolean => {
    return visible && !disabled;
  };
  